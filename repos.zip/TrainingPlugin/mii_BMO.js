function OnChangeMasterBMO(executionContext) {
    var formContext = executionContext.getFormContext();

    if (formContext.getAttribute("mii_masterbmo").getValue() !== undefined && formContext.getAttribute("mii_masterbmo").getValue() !== null) {

        var id = formContext.getAttribute("mii_masterbmo").getValue()[0].id;

        Xrm.WebApi.retrieveRecord("mii_masterbmo", id, "?$select=mii_name").then(
            function success(result) {
            formContext.getAttribute("mii_asal").setValue(result.mii_name);
        }
        )
        formContext.getAttribute("mii_gender").setRequiredLevel("required");
        formContext.getControl("mii_age").setVisible(true);
        formContext.getControl("mii_salary").setDisabled(true);
    } else {
        formContext.getAttribute("mii_gender").setRequiredLevel("none");
        formContext.getControl("mii_age").setVisible(false);
        formContext.getAttribute("mii_asal").setValue(null);
        formContext.getControl("mii_salary").setDisabled(false);

    }

}

function OnLoad(executionContext) {
    OnChangeMasterBMO(executionContext);
}