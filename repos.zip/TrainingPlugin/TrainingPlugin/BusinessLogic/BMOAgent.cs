﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TrainingPlugin.BusinessLogic
{
    public class BMOAgent
    {
        public void setAge(IOrganizationService organizationService, IPluginExecutionContext pluginExecutionContext)
        {
            try
            {
                if (!(pluginExecutionContext.InputParameters.Contains("Target") &&
                      pluginExecutionContext.InputParameters["Target"] is Entity &&
                      pluginExecutionContext.MessageName == "Create")) return;

                var entity = (Entity)pluginExecutionContext.InputParameters["Target"];
                var context = new OrganizationServiceContext(organizationService);

                var settingEntities = (from x in context.CreateQuery("cra24_setting") 
                                        where x.GetAttributeValue<string>("cra24_name") == "Running Number Case"
                                        select x).ToList();

                if(settingEntities.Count > 0)
                {
                    int runningNumber = Convert.ToInt32(settingEntities[0].GetAttributeValue<string>("cra24_value")) + 1;
                    //entity.Attributes["cra24_name"] = entity.GetAttributeValue<string>("cra24_first") + "-" + entity.GetAttributeValue<string>("cra24_last") + "-" + runningNumber.ToString("0000");
                    entity.Attributes["mii_name"] = entity.GetAttributeValue<string>("mii_name") + "-" + runningNumber.ToString("0000");

                    var setting = new Entity("cra24_setting");
                    setting.Id = settingEntities[0].Id;
                    setting.Attributes["cra24_value"] = runningNumber;
                    organizationService.Update(setting);
                }
                else
                {
                    throw new InvalidPluginExecutionException("Setting not Completed");
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(
                    $"Error on set case number. Function Call: {MethodBase.GetCurrentMethod()}. Technical Detail: {ex.Message}");
            }
        }

        public void UpdateAge(IOrganizationService organizationService, IPluginExecutionContext pluginExecutionContext)
        {
            try
            {
                if (!(pluginExecutionContext.InputParameters.Contains("Target") &&
                      pluginExecutionContext.InputParameters["Target"] is Entity &&
                      pluginExecutionContext.MessageName == "Create")) return;

                var entity = (Entity)pluginExecutionContext.InputParameters["Target"];
                var context = new OrganizationServiceContext(organizationService);

                //var setting = new Entity("cra24_setting");
                //setting.Id = settingEntities[0].Id;
                //setting.Attributes["cra24_value"] = runningNumber;
                //organizationService.Update(setting);

                var ent = (from x in context.CreateQuery("cra24_trainingmanagement")
                           where x.GetAttributeValue<Guid>("cra24_trainingmanagementid") == entity.Id
                           select x).ToList();
                var entUpdate = new Entity("cra24_trainingmanagement");
                entUpdate.Attributes["cra24_name"] = ent[0].GetAttributeValue<string>("cra24_first") + "-" + ent[0].GetAttributeValue<string>("cra24_last") + "-" + ent[0].GetAttributeValue<string>("cra24_name").Split('-')[2];

                organizationService.Update(entUpdate);
                //untuk delete nama entity sama id entity
                //organizationService.Delete("cra24_trainingmanagement", entity.Id);
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(
                    $"Error on set case number. Function Call: {MethodBase.GetCurrentMethod()}. Technical Detail: {ex.Message}");
            }
        }
    }
}
