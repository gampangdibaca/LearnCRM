﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GeneralLoanPlugin.Business
{
    class SmallLoanAgent
    {
        public void setSmallLoanNumber(IOrganizationService organizationService, IPluginExecutionContext pluginExecutionContext)
        {
            try
            {
                if (!(pluginExecutionContext.InputParameters.Contains("Target") &&
                      pluginExecutionContext.InputParameters["Target"] is Entity &&
                      pluginExecutionContext.MessageName == "Create")) return;

                var entity = (Entity)pluginExecutionContext.InputParameters["Target"];
                var context = new OrganizationServiceContext(organizationService);

                var settingEntity = (from x in context.CreateQuery("ls_settinggeneralloan")
                                     where x.GetAttributeValue<string>("ls_name") == "Counting Number"
                                     select x).ToList();

                if (settingEntity.Count() > 0)
                {
                    int runningNumber = Convert.ToInt32(settingEntity[0].GetAttributeValue<string>("ls_value")) + 1;
                    entity.Attributes["ls_name"] = entity.GetAttributeValue<string>("ls_name") + "-" + runningNumber.ToString("0000");

                    var setting = new Entity("ls_settinggeneralloan");
                    setting.Id = settingEntity[0].Id;
                    setting.Attributes["ls_value"] = runningNumber.ToString();
                    organizationService.Update(setting);
                }
                else
                {
                    throw new InvalidPluginExecutionException("Setting Not Completed");
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException($"Error on set case number. Function Call: {MethodBase.GetCurrentMethod()}. Technical Detail: {ex.Message}");
            }
        }
    }
}
