﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PluginTraining.Business
{
    public class TrainingManagementAgent
    {
        public void setTrainingNumber(IOrganizationService organizationService, IPluginExecutionContext pluginExecutionContext)
        {
            try
            {
                if (!(pluginExecutionContext.InputParameters.Contains("Target") &&
                      pluginExecutionContext.InputParameters["Target"] is Entity &&
                      pluginExecutionContext.MessageName == "Create")) return;

                var entity = (Entity)pluginExecutionContext.InputParameters["Target"];
                var context = new OrganizationServiceContext(organizationService);

                var settingEntity = (from x in context.CreateQuery("cra24_setting")
                                     where x.GetAttributeValue<string>("cra24_name") == "Runing Number Case"
                                     select x).ToList();

                if (settingEntity.Count() > 0)
                {
                    int runningNumber = Convert.ToInt32(settingEntity[0].GetAttributeValue<string>("cra24_value")) + 1;
                    entity.Attributes["cra24_name"] = entity.GetAttributeValue<string>("cra24_first") + "-" + entity.GetAttributeValue<string>("cra24_last") + "-" + runningNumber.ToString("0000");
                    
                    var setting = new Entity("cra24_setting");
                    setting.Id = settingEntity[0].Id;
                    setting.Attributes["cra24_value"] = runningNumber.ToString();
                    organizationService.Update(setting);
                }
                else
                {
                    throw new InvalidPluginExecutionException("Setting Not Completed");
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException( $"Error on set case number. Function Call: {MethodBase.GetCurrentMethod()}. Technical Detail: {ex.Message}");
            }
        }

        public void UpdateTrainingNumber(IOrganizationService organizationService, IPluginExecutionContext pluginExecutionContext)
        {
            try
            {
                if (!(pluginExecutionContext.InputParameters.Contains("Target") &&
                      pluginExecutionContext.InputParameters["Target"] is Entity &&
                      pluginExecutionContext.MessageName == "Update")) return;

                var entity = (Entity)pluginExecutionContext.InputParameters["Target"];
                var context = new OrganizationServiceContext(organizationService);

                var ent = (from x in context.CreateQuery("cra24_trainingmanagement")
                           where x.GetAttributeValue<Guid>("cra24_trainingmanagementid") == entity.Id
                           select x).ToList();

                string[] splited = ent[0].GetAttributeValue<string>("cra24_name").Split('-');

                var entUpdate = new Entity("cra24_trainingmanagement");
                entUpdate.Id = ent[0].Id;
                entUpdate.Attributes["cra24_name"] = ent[0].GetAttributeValue<string>("cra24_first") + "-" + ent[0].GetAttributeValue<string>("cra24_last") + "-" + splited[2].ToString();
                organizationService.Update(entUpdate);

                //organizationService.Create(entUpdate);
                //organizationService.Delete("cra24_trainingmanagement", entity.Id);

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException($"Error on set case number. Function Call: {MethodBase.GetCurrentMethod()}. Technical Detail: {ex.Message}");
            }
        }
    }
}
