function OnChangeSettingLookup(executionContext) {
    var formContext = executionContext.getFormContext();
    if (formContext.getAttribute("cra24_settinglookup").getValue() !== undefined && formContext.getAttribute("cra24_settinglookup").getValue() !== null) {
        var id = formContext.getAttribute("cra24_settinglookup").getValue()[0].id;

        Xrm.WebApi.retrieveRecord("cra24_setting", id, "?$select=cra24_value").then(
            function success(result) {
                formContext.getAttribute("cra24_valuesetting").setValue(result.cra24_value);
            }
        )
    } else {
        formContext.getAttribute("cra24_valuesetting").setValue(null);
    }
}