function OnChangeDOB(executionContext) {
    var formContext = executionContext.getFormContext();

    if (formContext.getAttribute("ls_dob").getValue() !== undefined && formContext.getAttribute("ls_dob").getValue() !== null) {
        console.log(formContext.getAttribute("ls_dob").getValue());
        let dob = formContext.getAttribute("ls_dob").getValue();
        var month_diff = Date.now() - dob.getTime();

        //convert the calculated difference in date format  
        var age_dt = new Date(month_diff);

        //extract year from date      
        var year = age_dt.getUTCFullYear();

        //now calculate the age of the user  
        var age = Math.abs(year - 1970);
        formContext.getAttribute("ls_age").setValue(age);
        //var id = formContext.getAttribute("mii_masterbmo").getValue()[0].id;

        //Xrm.WebApi.retrieveRecord("mii_masterbmo", id, "?$select=mii_name").then(
        //    function success(result) {
        //        formContext.getAttribute("mii_asal").setValue(result.mii_name);
        //    }
        //)
        //formContext.getAttribute("mii_gender").setRequiredLevel("required");
        //formContext.getControl("mii_age").setVisible(true);
        //formContext.getControl("mii_salary").setDisabled(true);
    } else {
        console.log("NONE");
        formContext.getAttribute("ls_age").setValue(null);
        //formContext.getAttribute("mii_gender").setRequiredLevel("none");
        //formContext.getControl("mii_age").setVisible(false);
        //formContext.getAttribute("mii_asal").setValue(null);
        //formContext.getControl("mii_salary").setDisabled(false);

    }

}